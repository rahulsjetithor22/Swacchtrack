# Backend starter

The original server-side attendance functions and Firestore rules should be integrated and reviewed separately before real use. This mobile-build pack intentionally focuses on creating an installable prototype APK. Do not connect this prototype to real worker data until the backend is reviewed and tested.
