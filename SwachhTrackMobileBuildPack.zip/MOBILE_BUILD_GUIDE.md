# Mobile-only build guide (Android phone)

## Part A — Create a GitHub repository
1. Open https://github.com in Chrome and sign in or create an account.
2. Use the `+` menu and choose **New repository**.
3. Name it `SwachhTrack`, choose **Private**, and create it.
4. Keep the repository page open.

## Part B — Upload this pack
1. Download `SwachhTrackMobileBuildPack.zip` to your phone.
2. On the repository page, choose **Add file → Upload files** and upload the ZIP file itself.
3. Commit the upload to the `main` branch.

## Part C — Unzip it in a cloud workspace
1. In the repository, open the green **Code** button → **Codespaces** → **Create codespace on main**. If Codespaces is unavailable or quota is exhausted, stop and tell me what you see; do not pay for a plan without checking the cost first.
2. Wait for the browser editor to load. In the terminal panel, run:
   `ls`
3. The ZIP should be in the repository. Run:
   `unzip SwachhTrackMobileBuildPack.zip -d extracted`
4. Move the extracted project files into the repository root:
   `cp -R extracted/. .`
5. Remove the uploaded ZIP and temporary folder:
   `rm -rf extracted SwachhTrackMobileBuildPack.zip`
6. Commit the files:
   `git add .`
   `git commit -m "Add SwachhTrack mobile build project"`
   `git push`
   If Git asks you to sign in, follow the GitHub browser authentication flow.

## Part D — Download the APK
1. Return to the repository on GitHub.
2. Open **Actions**.
3. Choose **Build Android APK** and open the latest run.
4. Wait until the workflow finishes with a green check mark.
5. Under **Artifacts**, tap `swachhtrack-debug-apk` to download it.
6. Open your phone's Downloads folder and extract the artifact ZIP.
7. Tap `app-debug.apk`. Android may ask you to allow installs from Chrome or Files. Only allow this for the trusted download you just built, then install.
8. If Android blocks the installation, note the exact message and ask for help rather than downloading APKs from unknown sites.

## What to expect
The app should open to a prototype Ward 9 screen and clearly indicate that Firebase and approved GIS configuration are still required. It is not ready for actual worker attendance, payroll, or official PCMC use.

## If the build fails
Open Actions → failed workflow → open the red failed step → copy the first error and share it. Do not share tokens, passwords, private keys, or Firebase service-account JSON.
