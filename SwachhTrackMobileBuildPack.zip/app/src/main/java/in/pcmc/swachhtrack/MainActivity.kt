package in.pcmc.swachhtrack

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 36)
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        val title = TextView(this).apply {
            text = "SwachhTrack"
            textSize = 30f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF123B2A.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Ward No. 9 • Nehrunagar, Pimpri"
            textSize = 17f
            setPadding(0, 8, 0, 20)
            setTextColor(0xFF333333.toInt())
        }
        val notice = TextView(this).apply {
            text = "100-worker pilot prototype\\n\\nThis APK is a UI/build prototype only. Firebase sign-in, server validation, approved road GIS and SI review must be configured and tested before attendance can be recorded."
            textSize = 16f
            setTextColor(0xFF222222.toInt())
            setPadding(20, 20, 20, 20)
            setBackgroundColor(0xFFE7F0EB.toInt())
        }
        val status = TextView(this).apply {
            text = "Status: Setup required — no attendance has been recorded."
            textSize = 15f
            setPadding(0, 22, 0, 22)
            setTextColor(0xFF7A341E.toInt())
        }
        val buttons = listOf(
            "Worker sign-in" to "Firebase Authentication is not configured yet.",
            "GPS check-in" to "Disabled until secure backend and official route GIS are configured.",
            "GPS check-out" to "Disabled until secure backend and official route GIS are configured.",
            "SI review" to "SI role and ward permissions are not configured yet.",
            "Daily report" to "Reports become available after secure backend setup."
        )
        page.addView(title)
        page.addView(subtitle)
        page.addView(notice)
        page.addView(status)
        buttons.forEach { (label, message) ->
            val button = Button(this).apply {
                text = label
                isAllCaps = false
                setOnClickListener {
                    android.widget.Toast.makeText(this@MainActivity, message, android.widget.Toast.LENGTH_LONG).show()
                }
            }
            page.addView(button, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 8 })
        }
        val footer = TextView(this).apply {
            text = "Prototype only • Not approved for official attendance/payroll"
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 8)
        }
        page.addView(footer)
        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }
}
