# SwachhTrack mobile build pack

Pilot: Ward No. 9 — Nehrunagar, Pimpri | 100-worker pilot

This pack is designed so a user can upload it to a GitHub repository and use GitHub Actions to build a debug APK from a phone browser.

## Important status
- The Android app in this pack is a **buildable prototype shell**, not a production attendance app.
- It shows the Ward 9 pilot screen and a setup warning. Attendance actions are not enabled until Firebase Auth, Cloud Functions, official route GIS, and policies are configured.
- The Cloud Functions and Firestore rules are starter examples and must be reviewed, tested and configured before real attendance use.
- No PCMC approval, production build, or field testing is claimed.

## Build on mobile
See `MOBILE_BUILD_GUIDE.md`.

## GitHub Actions output
After pushing the project to GitHub, open the repository's **Actions** tab, select the latest `Build Android APK` run, and download the `swachhtrack-debug-apk` artifact. Extract the downloaded artifact ZIP to find `app-debug.apk`.

## Firebase setup
`app/google-services.json` is intentionally not included. Add the configuration file from your own Firebase project only after creating/configuring that project. Do not commit service-account keys or secrets.
